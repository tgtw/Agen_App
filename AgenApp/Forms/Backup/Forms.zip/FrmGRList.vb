﻿Imports System.Data.SqlClient

Public Class FrmGRList

    Dim LebarLayar As Long = 0

    Private Sub Load_Data(SQL As String, DTG As DataGridView)

        Try
            CMD = New SqlCommand
            DA = New SqlDataAdapter
            DT = New DataTable

            CMD.Connection = Conn
            CMD.CommandText = SQL

            DA.SelectCommand = CMD
            DA.Fill(DT)

            With DTG

                .DataSource = DT

                .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
                .ColumnHeadersHeight = 30

                '.ColumnHeadersDefaultCellStyle.Font = New Font("Verdana", 9)

                .Columns(0).HeaderText = "DOC NO"
                .Columns(1).HeaderText = "DOC DATE"
                .Columns(2).HeaderText = "PO NO"
                .Columns(3).HeaderText = "PO DATE"
                .Columns(4).HeaderText = "VENDOR"
                .Columns(5).HeaderText = "DELV NO"
                .Columns(6).HeaderText = "NOTES"

                .Columns(0).Width = 100
                .Columns(1).Width = 110
                .Columns(2).Width = 100
                .Columns(3).Width = 110
                .Columns(4).Width = 250
                .Columns(5).Width = 100
                .Columns(6).Width = 300

                .Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill

            End With

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Conn.Close()
            DA.Dispose()
        End Try

    End Sub

    Private Sub FrmGRList_Leave(sender As Object, e As EventArgs) Handles Me.Leave
        MDIMain.ToolStrip.Visible = True
    End Sub

    Private Sub FrmGRList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Call Local_Connect()

        If ConnectStatus = False Then Exit Sub

        '=====================
        ' DataGridView Design
        '=====================

        DGV.BorderStyle = BorderStyle.Fixed3D
        DGV.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249)
        DGV.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        DGV.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise
        DGV.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke
        DGV.BackgroundColor = Color.White

        DGV.EnableHeadersVisualStyles = False
        DGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        DGV.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72)
        DGV.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        'DGV.RowHeadersVisible = False


        Query = "SELECT grno,grdate,pono,podate,nmsupl,delvno,notes FROM [TRANGRH] ORDER BY [grno] "

        Call Load_Data(Query, DGV)


    End Sub

    Private Sub tsbExit_Click(sender As Object, e As EventArgs) Handles tsbExit.Click
        Me.Close()
    End Sub

    Private Sub tsbNew_Click(sender As Object, e As EventArgs) Handles tsbNew.Click

        FrmGR.ShowDialog()

        Query = "SELECT grno,grdate,pono,podate,nmsupl,delvno,notes FROM [TRANGRH] ORDER BY [grno] "

        Call Load_Data(Query, DGV)

    End Sub

    Private Sub tsbPrintGRN_Click(sender As Object, e As EventArgs) Handles tsbPrintGRN.Click

        Dim SLOCINFO As String = ""

        Query = "SELECT  TRANGRH.GRNO, TRANGRH.GRDATE, TRANGRH.PONO, TRANGRH.PODATE, TRANGRH.NMSUPL, TRANGRH.DELVNO, TRANGRH.NOTES," & _
                "        TRANGRD.ITEMNO, TRANGRD.KDPROD, TRANGRD.NMPROD, TRANGRD.QTYRECV1, TRANGRD.QTYRECV2, TRANGRD.UNIT, TRANGRD.SLOC " & _
                "FROM    TRANGRD INNER JOIN TRANGRH ON TRANGRD.GRNO = TRANGRH.GRNO " & _
                "WHERE   TRANGRH.GRNO = '" & DGV.CurrentRow.Cells(0).Value.ToString & "'"

        DS = New DataSet
        DA = New SqlDataAdapter(Query, Conn)
        DA.Fill(DS, "GR")

        SLOCINFO = DS.Tables("GR").Rows(0)("SLOC")
        SLOCINFO = SLOCINFO & "-" & SLOC_INFO(SLOCINFO)

        Dim PrintControl As New ClassPrintReport

        PrintControl.CetakReport("RptGRNote.rdlc", "DataSet1", Query, SLOCINFO)

    End Sub

End Class