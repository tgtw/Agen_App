﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDIMain))
        Me.tsbPurchaseOrder = New System.Windows.Forms.ToolStripButton()
        Me.tsbGoodsReceipt = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.tsbCustomer = New System.Windows.Forms.ToolStripButton()
        Me.tsbProduct = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbSalesReceipt = New System.Windows.Forms.ToolStripButton()
        Me.tsbSalesInvoice = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbStockReport = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbExit = New System.Windows.Forms.ToolStripButton()
        Me.mnuReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRptStock = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuRptSales = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuTransPurchase = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransPurchaseBO = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuTransPurchasePO = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuTransPurchaseGR = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTrans = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransSales = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransSalesReceipt = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuTransSalesInvoice = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.GoodsMovementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SrappingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.TransferStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuMasterProduct = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterCustomer = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuMasterVendor = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.statuslbl1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.statuslbl2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.statuslbl3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.statuslbl4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tsbPurchaseOrder
        '
        Me.tsbPurchaseOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbPurchaseOrder.Image = CType(resources.GetObject("tsbPurchaseOrder.Image"), System.Drawing.Image)
        Me.tsbPurchaseOrder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbPurchaseOrder.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPurchaseOrder.Name = "tsbPurchaseOrder"
        Me.tsbPurchaseOrder.Padding = New System.Windows.Forms.Padding(2)
        Me.tsbPurchaseOrder.Size = New System.Drawing.Size(141, 36)
        Me.tsbPurchaseOrder.Text = " Purchase Order"
        '
        'tsbGoodsReceipt
        '
        Me.tsbGoodsReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbGoodsReceipt.Image = CType(resources.GetObject("tsbGoodsReceipt.Image"), System.Drawing.Image)
        Me.tsbGoodsReceipt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbGoodsReceipt.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbGoodsReceipt.Name = "tsbGoodsReceipt"
        Me.tsbGoodsReceipt.Size = New System.Drawing.Size(134, 36)
        Me.tsbGoodsReceipt.Text = " Goods Receipt"
        '
        'ToolStrip
        '
        Me.ToolStrip.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ToolStrip.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbCustomer, Me.tsbProduct, Me.ToolStripSeparator5, Me.tsbPurchaseOrder, Me.tsbGoodsReceipt, Me.ToolStripSeparator10, Me.tsbSalesReceipt, Me.tsbSalesInvoice, Me.ToolStripSeparator11, Me.tsbStockReport, Me.ToolStripSeparator12, Me.tsbExit})
        Me.ToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Padding = New System.Windows.Forms.Padding(0, 2, 0, 2)
        Me.ToolStrip.Size = New System.Drawing.Size(1098, 43)
        Me.ToolStrip.TabIndex = 12
        Me.ToolStrip.Text = "ToolStrip"
        '
        'tsbCustomer
        '
        Me.tsbCustomer.Image = CType(resources.GetObject("tsbCustomer.Image"), System.Drawing.Image)
        Me.tsbCustomer.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbCustomer.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbCustomer.Name = "tsbCustomer"
        Me.tsbCustomer.Size = New System.Drawing.Size(100, 36)
        Me.tsbCustomer.Text = " Customer "
        '
        'tsbProduct
        '
        Me.tsbProduct.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbProduct.Image = CType(resources.GetObject("tsbProduct.Image"), System.Drawing.Image)
        Me.tsbProduct.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbProduct.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbProduct.Name = "tsbProduct"
        Me.tsbProduct.Size = New System.Drawing.Size(92, 36)
        Me.tsbProduct.Text = " Product "
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 39)
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 39)
        '
        'tsbSalesReceipt
        '
        Me.tsbSalesReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbSalesReceipt.Image = CType(resources.GetObject("tsbSalesReceipt.Image"), System.Drawing.Image)
        Me.tsbSalesReceipt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbSalesReceipt.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSalesReceipt.Name = "tsbSalesReceipt"
        Me.tsbSalesReceipt.Size = New System.Drawing.Size(128, 36)
        Me.tsbSalesReceipt.Text = " Sales Receipt"
        '
        'tsbSalesInvoice
        '
        Me.tsbSalesInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbSalesInvoice.Image = CType(resources.GetObject("tsbSalesInvoice.Image"), System.Drawing.Image)
        Me.tsbSalesInvoice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbSalesInvoice.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSalesInvoice.Name = "tsbSalesInvoice"
        Me.tsbSalesInvoice.Size = New System.Drawing.Size(124, 36)
        Me.tsbSalesInvoice.Text = " Sales Invoice"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 39)
        '
        'tsbStockReport
        '
        Me.tsbStockReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbStockReport.Image = CType(resources.GetObject("tsbStockReport.Image"), System.Drawing.Image)
        Me.tsbStockReport.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbStockReport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbStockReport.Name = "tsbStockReport"
        Me.tsbStockReport.Size = New System.Drawing.Size(150, 36)
        Me.tsbStockReport.Text = " Warehouse Stock"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 39)
        '
        'tsbExit
        '
        Me.tsbExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbExit.Image = CType(resources.GetObject("tsbExit.Image"), System.Drawing.Image)
        Me.tsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbExit.Name = "tsbExit"
        Me.tsbExit.Size = New System.Drawing.Size(64, 36)
        Me.tsbExit.Text = " Exit"
        '
        'mnuReport
        '
        Me.mnuReport.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuRptStock, Me.ToolStripSeparator13, Me.mnuRptSales})
        Me.mnuReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuReport.Name = "mnuReport"
        Me.mnuReport.Size = New System.Drawing.Size(61, 20)
        Me.mnuReport.Text = "Report"
        '
        'mnuRptStock
        '
        Me.mnuRptStock.Image = CType(resources.GetObject("mnuRptStock.Image"), System.Drawing.Image)
        Me.mnuRptStock.Name = "mnuRptStock"
        Me.mnuRptStock.Size = New System.Drawing.Size(183, 22)
        Me.mnuRptStock.Text = "Warehouse Stock"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(180, 6)
        '
        'mnuRptSales
        '
        Me.mnuRptSales.Image = CType(resources.GetObject("mnuRptSales.Image"), System.Drawing.Image)
        Me.mnuRptSales.Name = "mnuRptSales"
        Me.mnuRptSales.Size = New System.Drawing.Size(183, 22)
        Me.mnuRptSales.Text = "Sales Detail"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(180, 6)
        '
        'mnuTransPurchase
        '
        Me.mnuTransPurchase.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTransPurchaseBO, Me.ToolStripSeparator7, Me.mnuTransPurchasePO, Me.ToolStripSeparator8, Me.mnuTransPurchaseGR})
        Me.mnuTransPurchase.Image = CType(resources.GetObject("mnuTransPurchase.Image"), System.Drawing.Image)
        Me.mnuTransPurchase.ImageTransparentColor = System.Drawing.Color.Black
        Me.mnuTransPurchase.Name = "mnuTransPurchase"
        Me.mnuTransPurchase.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.mnuTransPurchase.ShowShortcutKeys = False
        Me.mnuTransPurchase.Size = New System.Drawing.Size(183, 22)
        Me.mnuTransPurchase.Text = "Purchase"
        '
        'mnuTransPurchaseBO
        '
        Me.mnuTransPurchaseBO.Image = CType(resources.GetObject("mnuTransPurchaseBO.Image"), System.Drawing.Image)
        Me.mnuTransPurchaseBO.Name = "mnuTransPurchaseBO"
        Me.mnuTransPurchaseBO.Size = New System.Drawing.Size(170, 22)
        Me.mnuTransPurchaseBO.Text = "Booking Order"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(167, 6)
        '
        'mnuTransPurchasePO
        '
        Me.mnuTransPurchasePO.Image = CType(resources.GetObject("mnuTransPurchasePO.Image"), System.Drawing.Image)
        Me.mnuTransPurchasePO.Name = "mnuTransPurchasePO"
        Me.mnuTransPurchasePO.Size = New System.Drawing.Size(170, 22)
        Me.mnuTransPurchasePO.Text = "Purchase Order"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(167, 6)
        '
        'mnuTransPurchaseGR
        '
        Me.mnuTransPurchaseGR.Image = CType(resources.GetObject("mnuTransPurchaseGR.Image"), System.Drawing.Image)
        Me.mnuTransPurchaseGR.Name = "mnuTransPurchaseGR"
        Me.mnuTransPurchaseGR.Size = New System.Drawing.Size(170, 22)
        Me.mnuTransPurchaseGR.Text = "Goods Receipt"
        '
        'mnuTrans
        '
        Me.mnuTrans.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTransPurchase, Me.ToolStripSeparator1, Me.mnuTransSales, Me.ToolStripSeparator2, Me.GoodsMovementToolStripMenuItem})
        Me.mnuTrans.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuTrans.Name = "mnuTrans"
        Me.mnuTrans.Size = New System.Drawing.Size(91, 20)
        Me.mnuTrans.Text = "Transaction"
        '
        'mnuTransSales
        '
        Me.mnuTransSales.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTransSalesReceipt, Me.ToolStripSeparator9, Me.mnuTransSalesInvoice})
        Me.mnuTransSales.Image = CType(resources.GetObject("mnuTransSales.Image"), System.Drawing.Image)
        Me.mnuTransSales.ImageTransparentColor = System.Drawing.Color.Black
        Me.mnuTransSales.Name = "mnuTransSales"
        Me.mnuTransSales.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.J), System.Windows.Forms.Keys)
        Me.mnuTransSales.ShowShortcutKeys = False
        Me.mnuTransSales.Size = New System.Drawing.Size(183, 22)
        Me.mnuTransSales.Text = "Sales"
        '
        'mnuTransSalesReceipt
        '
        Me.mnuTransSalesReceipt.Name = "mnuTransSalesReceipt"
        Me.mnuTransSalesReceipt.Size = New System.Drawing.Size(161, 22)
        Me.mnuTransSalesReceipt.Text = "Sales Receipt"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(158, 6)
        '
        'mnuTransSalesInvoice
        '
        Me.mnuTransSalesInvoice.Name = "mnuTransSalesInvoice"
        Me.mnuTransSalesInvoice.Size = New System.Drawing.Size(161, 22)
        Me.mnuTransSalesInvoice.Text = "Sales Invoice"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(180, 6)
        '
        'GoodsMovementToolStripMenuItem
        '
        Me.GoodsMovementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SrappingToolStripMenuItem, Me.ToolStripSeparator3, Me.TransferStockToolStripMenuItem})
        Me.GoodsMovementToolStripMenuItem.Name = "GoodsMovementToolStripMenuItem"
        Me.GoodsMovementToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.GoodsMovementToolStripMenuItem.Text = "Goods Movement"
        '
        'SrappingToolStripMenuItem
        '
        Me.SrappingToolStripMenuItem.Name = "SrappingToolStripMenuItem"
        Me.SrappingToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.SrappingToolStripMenuItem.Text = "Scrapping"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(160, 6)
        '
        'TransferStockToolStripMenuItem
        '
        Me.TransferStockToolStripMenuItem.Name = "TransferStockToolStripMenuItem"
        Me.TransferStockToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.TransferStockToolStripMenuItem.Text = "Transfer Stock"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(174, 6)
        '
        'mnuMasterProduct
        '
        Me.mnuMasterProduct.Image = CType(resources.GetObject("mnuMasterProduct.Image"), System.Drawing.Image)
        Me.mnuMasterProduct.ImageTransparentColor = System.Drawing.Color.Black
        Me.mnuMasterProduct.Name = "mnuMasterProduct"
        Me.mnuMasterProduct.Size = New System.Drawing.Size(177, 22)
        Me.mnuMasterProduct.Text = "Product Master"
        '
        'mnuMaster
        '
        Me.mnuMaster.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMasterProduct, Me.ToolStripSeparator6, Me.mnuMasterCustomer, Me.ToolStripSeparator4, Me.mnuMasterVendor})
        Me.mnuMaster.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuMaster.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.mnuMaster.Name = "mnuMaster"
        Me.mnuMaster.Size = New System.Drawing.Size(93, 20)
        Me.mnuMaster.Text = "Master Data"
        '
        'mnuMasterCustomer
        '
        Me.mnuMasterCustomer.Name = "mnuMasterCustomer"
        Me.mnuMasterCustomer.Size = New System.Drawing.Size(177, 22)
        Me.mnuMasterCustomer.Text = "Customer Master"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(174, 6)
        '
        'mnuMasterVendor
        '
        Me.mnuMasterVendor.Name = "mnuMasterVendor"
        Me.mnuMasterVendor.Size = New System.Drawing.Size(177, 22)
        Me.mnuMasterVendor.Text = "Vendor Master"
        '
        'MenuStrip
        '
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.GripMargin = New System.Windows.Forms.Padding(1)
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaster, Me.mnuTrans, Me.mnuReport})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip.Size = New System.Drawing.Size(1098, 24)
        Me.MenuStrip.TabIndex = 11
        Me.MenuStrip.Text = "MenuStrip"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statuslbl1, Me.statuslbl2, Me.statuslbl3, Me.statuslbl4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 441)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1098, 22)
        Me.StatusStrip1.TabIndex = 16
        '
        'statuslbl1
        '
        Me.statuslbl1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.statuslbl1.Name = "statuslbl1"
        Me.statuslbl1.Size = New System.Drawing.Size(876, 17)
        Me.statuslbl1.Spring = True
        Me.statuslbl1.Text = "statuslabel1"
        Me.statuslbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'statuslbl2
        '
        Me.statuslbl2.Name = "statuslbl2"
        Me.statuslbl2.Size = New System.Drawing.Size(69, 17)
        Me.statuslbl2.Text = "statuslabel2"
        '
        'statuslbl3
        '
        Me.statuslbl3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.statuslbl3.Name = "statuslbl3"
        Me.statuslbl3.Size = New System.Drawing.Size(69, 17)
        Me.statuslbl3.Text = "statuslabel3"
        '
        'statuslbl4
        '
        Me.statuslbl4.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.statuslbl4.Name = "statuslbl4"
        Me.statuslbl4.Size = New System.Drawing.Size(69, 17)
        Me.statuslbl4.Text = "statuslabel4"
        '
        'MDIMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.GhostWhite
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1098, 463)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.IsMdiContainer = True
        Me.Name = "MDIMain"
        Me.Text = "SIASAT [Sistem Informasi Agen - SAP Terpadu]"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tsbPurchaseOrder As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbGoodsReceipt As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents mnuReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuTransPurchase As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTrans As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransSales As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuMasterProduct As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents mnuMasterCustomer As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuMasterVendor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransPurchaseBO As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransPurchasePO As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransPurchaseGR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbExit As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSalesReceipt As System.Windows.Forms.ToolStripButton
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents statuslbl1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnuTransSalesReceipt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuTransSalesInvoice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbSalesInvoice As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbProduct As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnuRptStock As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents statuslbl2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statuslbl3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statuslbl4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GoodsMovementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SrappingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TransferStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbStockReport As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbCustomer As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuRptSales As System.Windows.Forms.ToolStripMenuItem

End Class
